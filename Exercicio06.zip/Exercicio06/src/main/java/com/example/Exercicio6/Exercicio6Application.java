package com.example.Exercicio6;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Exercicio6Application {
	public static void main(String[] args) {
		SpringApplication.run(Exercicio6Application.class, args);
	}

}

